import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.cluster import KMeans
from sklearn.metrics import r2_score, mean_squared_error
import xgboost as xgb
import os
from scipy import stats

# 1. 设置输出文件夹
output_folder = r"F:\revision\XGBOOST"
os.makedirs(output_folder, exist_ok=True)

# 2. 读取数据
print("步骤1: 读取数据...")
data = pd.read_excel(os.path.join(output_folder, "random_points_with_coordinates.xlsx"))
print("数据列名:", data.columns.tolist())  # 打印列名用于确认

# 3. 准备变量 - 修正坐标列名
print("\n步骤2: 准备变量...")
# 确保使用正确的列名
coords = data[['Coordinate_X(像素坐标）', 'Coordinate_Y（像素坐标）']].values
features = ['SIC','RGDP','P','NDVI','PD','PS','T','UR','GTPI','WSF']
X = data[features].values
y = data['CE'].values

# 4. KMeans分区
print("步骤3: 空间分区(KMeans聚类)...")
n_splits = 5
kmeans = KMeans(n_clusters=n_splits, random_state=42, n_init=10)
groups = kmeans.fit_predict(coords)
data['Region'] = groups  # 添加区域标签

# 5. 空间交叉验证
print("\n步骤4: 进行空间交叉验证...")

def run_folds(folds_to_run):
    results = []
    for fold in folds_to_run:
        test_idx = np.where(groups == fold)[0]
        train_idx = np.where(groups != fold)[0]
        
        X_train, X_test = X[train_idx], X[test_idx]
        y_train, y_test = y[train_idx], y[test_idx]
        
        model = xgb.XGBRegressor(
            n_estimators=200, max_depth=4, learning_rate=0.1,
            subsample=0.8, colsample_bytree=0.8,
            random_state=42, n_jobs=4
        )
        model.fit(X_train, y_train, verbose=False)
        
        y_pred = model.predict(X_test)
        r2 = r2_score(y_test, y_pred)
        rmse = mean_squared_error(y_test, y_pred, squared=False)
        
        results.append((fold, r2, rmse, len(test_idx)))
        print(f"Fold {fold}: R2 = {r2:.3f}, RMSE = {rmse:.3f}, 样本数 = {len(test_idx)}")
    return results

# 运行所有分区
all_results = run_folds(range(n_splits))

# 6. 保存交叉验证结果
print("\n==== 空间交叉验证结果 ====")
results_df = pd.DataFrame(all_results, columns=['Region', 'R2', 'RMSE', 'Samples'])
print(results_df)
results_csv = os.path.join(output_folder, "spatial_cv_results.csv")
results_df.to_csv(results_csv, index=False)
print(f"交叉验证结果已保存至: {results_csv}")

# 7. 分析各区域特征差异
print("\n步骤5: 分析各区域特征差异...")

# 计算整体均值
overall_mean = data[features].mean()
overall_std = data[features].std()

# 计算各区域均值
region_means = data.groupby('Region')[features].mean()
region_stds = data.groupby('Region')[features].std()

# 计算各区域与整体均值的差异百分比
region_diffs = (region_means - overall_mean) / overall_mean * 100

# 找出区域2差异最大的特征
region2_diffs = region_diffs.loc[2].abs().sort_values(ascending=False)
top_features = region2_diffs.head(3).index.tolist()
print(f"\n区域2与其他区域差异最大的特征: {top_features}")

# 8. 统计检验 - 区域2与其他区域差异显著性
print("\n步骤6: 进行统计检验...")
significance_results = []

for feature in features:
    # 区域2数据
    region2_data = data[data['Region'] == 2][feature]
    
    # 其他区域合并数据
    other_data = data[data['Region'] != 2][feature]
    
    # t检验
    t_stat, p_value = stats.ttest_ind(region2_data, other_data, equal_var=False)
    
    # 计算效应量
    mean_diff = region2_data.mean() - other_data.mean()
    cohens_d = mean_diff / np.sqrt((region2_data.std()**2 + other_data.std()**2) / 2)
    
    significance_results.append({
        'Feature': feature,
        'Region2_Mean': region2_data.mean(),
        'Other_Mean': other_data.mean(),
        'Mean_Diff': mean_diff,
        'P_value': p_value,
        'Significant': p_value < 0.05,
        'Cohens_d': cohens_d
    })

significance_df = pd.DataFrame(significance_results)
significance_csv = os.path.join(output_folder, "feature_significance.csv")
significance_df.to_csv(significance_csv, index=False)
print(f"特征显著性分析已保存至: {significance_csv}")

# 9. 创建图表
print("\n步骤7: 创建分析图表...")
plt.style.use('seaborn-whitegrid')

# -------------------------------
# 9. 创建分析图表（Times New Roman, fontsize=22）
# -------------------------------
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
import seaborn as sns

plt.style.use('seaborn-whitegrid')

# 全局字体设置为 Times New Roman, 大小 22
plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['font.size'] = 22
plt.rcParams['axes.unicode_minus'] = False    # 支持负号

# -------------------------------
# 9.1 空间分区图（KMeans）
# -------------------------------
plt.figure(figsize=(12, 10))
colors = ListedColormap(['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd'])

scatter = plt.scatter(
    data['Coordinate_X(像素坐标）'], 
    data['Coordinate_Y（像素坐标）'], 
    c=data['Region'], 
    cmap=colors, 
    s=60, 
    alpha=0.8,
    edgecolor='k',
    linewidth=0.5
)

cbar = plt.colorbar(scatter, ticks=range(5))
cbar.set_label('Region', fontsize=22)
cbar.set_ticklabels([f'Region {i}' for i in range(5)])
cbar.ax.tick_params(labelsize=18)

plt.xlabel('X Coordinate', fontsize=22)
plt.ylabel('Y Coordinate', fontsize=22)
plt.title('Spatial Clustering (KMeans, 5 Regions)', fontsize=24)
plt.axis('equal')
plt.margins(0.05)

region2_center = data[data['Region'] == 2][['Coordinate_X(像素坐标）', 'Coordinate_Y（像素坐标）']].mean()
offset_x = (data['Coordinate_X(像素坐标）'].max() - data['Coordinate_X(像素坐标）'].min()) * 0.03
offset_y = (data['Coordinate_Y（像素坐标）'].max() - data['Coordinate_Y（像素坐标）'].min()) * 0.03

plt.annotate(
    'Region 2 (Anomalous)',
    xy=(region2_center['Coordinate_X(像素坐标）'], region2_center['Coordinate_Y（像素坐标）']),
    xytext=(region2_center['Coordinate_X(像素坐标）'] - offset_x, region2_center['Coordinate_Y（像素坐标）'] + offset_y),
    arrowprops=dict(facecolor='red', shrink=0.05, width=2, headwidth=12),
    fontsize=22, color='red'
)

plt.grid(True, linestyle='--', alpha=0.5)
region_map = os.path.join(output_folder, "spatial_regions_times_new_roman.png")
plt.savefig(region_map, dpi=300, bbox_inches='tight')
plt.show()
print(f"Spatial clustering plot saved to: {region_map}")

# -------------------------------
# 9.2 各区域特征均值对比图
# -------------------------------
plt.figure(figsize=(16, 12))
top_features = region2_diffs.head(3).index.tolist()

for i, feature in enumerate(top_features):
    plt.subplot(2, 2, i+1)
    sns.barplot(x='Region', y=feature, data=data, ci='sd', capsize=0.1, palette='viridis')
    
    # 整体均值线
    plt.axhline(y=overall_mean[feature], color='r', linestyle='--', alpha=0.7)
    plt.text(4.5, overall_mean[feature], f'Overall Mean: {overall_mean[feature]:.2f}', 
             va='bottom', ha='right', color='r', fontsize=18)
    
    diff_percent = (region_means.loc[2, feature] - overall_mean[feature]) / overall_mean[feature] * 100
    diff_sign = "+" if diff_percent > 0 else ""
    p_val = significance_df[significance_df['Feature'] == feature]['P_value'].values[0]
    sig_star = "***" if p_val < 0.001 else "**" if p_val < 0.01 else "*" if p_val < 0.05 else ""
    
    plt.title(f'{feature} (Region 2 Difference: {diff_sign}{diff_percent:.1f}%){sig_star}', fontsize=22)
    plt.xlabel('Region', fontsize=20)
    plt.ylabel(feature, fontsize=20)
    plt.xticks(fontsize=18)
    plt.yticks(fontsize=18)

plt.tight_layout()
feature_comp = os.path.join(output_folder, "feature_comparison_times_new_roman.png")
plt.savefig(feature_comp, dpi=300, bbox_inches='tight')
plt.show()
print(f"Feature comparison plot saved to: {feature_comp}")

# -------------------------------
# 9.3 空间交叉验证结果图
# -------------------------------
plt.figure(figsize=(12, 8))
x = np.arange(len(results_df))
width = 0.35

r2_bars = plt.bar(x - width/2, results_df['R2'], width, label='R²', color='#1f77b4')
ax2 = plt.gca().twinx()
rmse_bars = ax2.bar(x + width/2, results_df['RMSE'], width, label='RMSE', color='#ff7f0e')

for i, (r2, rmse) in enumerate(zip(results_df['R2'], results_df['RMSE'])):
    plt.text(i - width/2, r2 + 0.02, f'{r2:.3f}', ha='center', va='bottom', fontsize=18)
    ax2.text(i + width/2, rmse + 0.2, f'{rmse:.3f}', ha='center', va='bottom', fontsize=18)

plt.xticks(x, [f'Region {i}' for i in range(n_splits)], fontsize=18)
plt.xlabel('Region', fontsize=22)
plt.ylabel('R²', fontsize=22)
ax2.set_ylabel('RMSE', fontsize=22)

r2_patch = plt.Rectangle((0,0),1,1,color='#1f77b4', label='R²')
rmse_patch = plt.Rectangle((0,0),1,1,color='#ff7f0e', label='RMSE')
plt.legend(handles=[r2_patch, rmse_patch], loc='upper right', fontsize=18)

plt.title('Spatial Cross-Validation Results', fontsize=24)
plt.grid(True, linestyle='--', alpha=0.3)

result_plot = os.path.join(output_folder, "cv_results_times_new_roman.png")
plt.savefig(result_plot, dpi=300, bbox_inches='tight')
plt.show()
print(f"Cross-validation plot saved to: {result_plot}")

# 10. 输出详细分析报告
print("\n==== 详细分析报告 ====")

# 10.1 区域2特征差异分析
print("\n区域2特征差异分析:")
print("特征 | 区域2均值 | 其他区域均值 | 差异百分比 | P值 | Cohen's d")
print("-" * 70)
for feature in top_features:
    region2_mean = region_means.loc[2, feature]
    other_mean = significance_df[significance_df['Feature'] == feature]['Other_Mean'].values[0]
    diff_pct = (region2_mean - other_mean) / other_mean * 100
    p_val = significance_df[significance_df['Feature'] == feature]['P_value'].values[0]
    cohens_d = significance_df[significance_df['Feature'] == feature]['Cohens_d'].values[0]
    
    print(f"{feature} | {region2_mean:.4f} | {other_mean:.4f} | {diff_pct:+.1f}% | {p_val:.4f} | {cohens_d:.2f}")

# 10.2 区域2表现异常的可能原因
print("\n区域2表现异常的可能原因分析:")
print("1. 特征极端值: 区域2在以下特征上有显著差异:")
for feature in top_features:
    diff_pct = (region_means.loc[2, feature] - overall_mean[feature]) / overall_mean[feature] * 100
    print(f"   - {feature}: {diff_pct:+.1f}%")
    
print("\n2. 特征交互作用: 区域2的独特特征组合可能导致模型失效")
print("3. 空间自相关: 区域2内部可能存在高度空间自相关")
print("4. 数据分布差异: 区域2的特征分布可能与其他区域不同")

# 10.3 改进建议
print("\n改进建议:")
print("1. 对区域2进行单独建模")
print("2. 添加交互特征或非线性变换")
print("3. 使用空间回归模型考虑空间自相关")
print("4. 增加区域2的样本量或特征工程")

# 11. 保存所有数据和结果
print("\n步骤8: 保存所有数据和结果...")

# 保存各区域特征均值
region_means_csv = os.path.join(output_folder, "region_feature_means.csv")
region_means.to_csv(region_means_csv)
print(f"各区域特征均值已保存至: {region_means_csv}")

# 保存各区域特征差异百分比
region_diffs_csv = os.path.join(output_folder, "region_feature_diffs.csv")
region_diffs.to_csv(region_diffs_csv)
print(f"各区域特征差异百分比已保存至: {region_diffs_csv}")

# 保存完整数据
all_data_path = os.path.join(output_folder, "all_data_with_regions.xlsx")
data.to_excel(all_data_path, index=False)
print(f"完整数据(含区域标签)已保存至: {all_data_path}")

print("\n==== 分析完成! ====")
