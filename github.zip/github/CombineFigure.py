import warnings
warnings.filterwarnings('ignore')
import shap
from sklearn.model_selection import train_test_split
import xgboost as xgb
import pandas as pd
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import numpy as np
import matplotlib.pyplot as plt

# 性能评估函数
def performance_reg(model, X, y, metrics_name=None):
    y_pred = model.predict(X)
    if metrics_name:
        print(metrics_name, ":")
    print("Mean Squared Error (MSE): ", mean_squared_error(y, y_pred))
    print("Root Mean Squared Error (RMSE): ", np.sqrt(mean_squared_error(y, y_pred)))
    print("Mean Absolute Error (MAE): ", mean_absolute_error(y, y_pred))
    print("R2 Score: ", r2_score(y, y_pred))
    print("----------------------------")

# 加载数据
data_path = r"F:\SY\tif\nonpp.csv"
data = pd.read_csv(data_path)
print("数据预览：\n", data.head())

# 数据预处理
data = data.dropna()
if 'CE' not in data.columns:
    raise ValueError("目标变量 'CE' 不在数据集中，请检查数据文件！")
X = data.drop(['CE'], axis=1)
y = data['CE']

# 划分数据集
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.3, random_state=2021, shuffle=True
)

# 构建模型
xgb_clf = xgb.XGBRegressor(
    objective='reg:squarederror',
    booster='gbtree',
    n_estimators=716,
    max_depth=5,
    reg_alpha=0.09,
    min_child_weight=0.66,
    colsample_bynode=0.65,
    subsample=0.75,
    learning_rate=0.164,
    scale_pos_weight=1.073,
    use_label_encoder=False
)

# 训练
xgb_clf.fit(X_train, y_train)
print("-----XGBOOST 训练完成-----")
performance_reg(xgb_clf, X_test, y_test, metrics_name='测试集')

# 计算 SHAP 值
print("正在计算SHAP值...")
explainer = shap.TreeExplainer(xgb_clf)
shap_values = explainer.shap_values(X_test)
shap_interaction_values = explainer.shap_interaction_values(X_test)

# 自动计算99%分位数范围，作为裁剪和x轴显示范围（最大不超过30）
flat_vals = np.abs(shap_interaction_values).flatten()
percentile_99 = np.percentile(flat_vals, 99)
clip_limit = min(max(percentile_99, 5), 30)  # 下限5，上限30，避免过小或过大

print(f"99%分位数绝对值：{percentile_99:.3f}, 裁剪和显示范围设为 ±{clip_limit:.2f}")

# 裁剪交互值
shap_interaction_values_clipped = np.clip(shap_interaction_values, -clip_limit, clip_limit)

# 修改后的绘图部分
plt.figure(figsize=(12, 8))
shap.summary_plot(
    shap_interaction_values_clipped, 
    X_test, 
    plot_type="dot",
    show=False,
    max_display=11
)

# 固定裁剪范围到 ±5，不再自动计算
clip_limit = 5  # 固定裁剪和显示范围

# 裁剪交互值（硬裁剪到±5）
shap_interaction_values_clipped = np.clip(shap_interaction_values, -clip_limit, clip_limit)

# 绘制 SHAP 交互总结图
plt.figure(figsize=(12, 8))
shap.summary_plot(
    shap_interaction_values_clipped, 
    X_test, 
    plot_type="dot", 
    show=False, 
    max_display=11  # 显示前11个重要特征
)

# 获取所有子图对象
axs = plt.gcf().get_axes()

# 强制统一所有子图的x轴范围和刻度
for ax in axs:
    # 设置x轴范围
    ax.set_xlim(-clip_limit, clip_limit)
    # 设置刻度位置为-5, 0, 5
    ax.set_xticks([-5, 0, 5])
    # 统一刻度标签字体大小
    ax.tick_params(axis='x', labelsize=12)

# 隐藏y轴标签（根据原需求）
plt.gca().set_yticklabels([])
plt.gca().set_ylabel('')  # 移除y轴标签

# 保存图像
plt.tight_layout()
plt.savefig("shap_interaction_summary_plot_clipped_5.png", dpi=600, bbox_inches="tight")
plt.show()
