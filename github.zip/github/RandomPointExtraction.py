import os  
import random  
import pandas as pd  
from osgeo import gdal  

# 设置全局随机数种子（如果需要每次运行都产生不同随机点）  
random.seed(None)  # 使用系统时间作为随机种子，确保每次运行随机性  

# 定义文件夹路径和TIFF文件路径  
folder_path = r"F:\SY\tif"  
tif_file = "combined_output.tif"  
tif_path = os.path.join(folder_path, tif_file)  

# 设置输出文件夹路径（修改为F:/revision/XGBOOST）
output_folder = r"F:/revision/XGBOOST"

# 确保输出文件夹存在
if not os.path.exists(output_folder):
    os.makedirs(output_folder)
    print(f"已创建输出文件夹: {output_folder}")

# 打开TIFF文件  
ds = gdal.Open(tif_path)  
if ds is None:
    raise FileNotFoundError(f"无法打开TIFF文件: {tif_path}")
    
num_bands = ds.RasterCount  # 获取波段数量  
num_points = 1200  # 每个文件生成随机点数量  

# 获取每个波段的名称  
band_names = [f'Band_{band_index}' for band_index in range(1, num_bands + 1)]  

# 初始化最终数据的DataFrame  
file_point_data_list = []  

# 为当前文件生成随机点数据  
for point_index in range(num_points):  
    # 生成随机点坐标（栅格坐标系）
    x = random.uniform(0, ds.RasterXSize - 1)  
    y = random.uniform(0, ds.RasterYSize - 1)  
    
    # 创建包含坐标信息的字典
    single_point_data = {
        'File': tif_file,
        'Point_ID': point_index,
        'Coordinate_X': x,  # 保存X坐标
        'Coordinate_Y': y   # 保存Y坐标
    }  

    # 添加每个波段的值到单点数据中  
    for band_index, band_name in enumerate(band_names, start=1):  
        band = ds.GetRasterBand(band_index)  
        value = band.ReadAsArray(int(x), int(y), 1, 1)[0][0]  # 读取波段值  
        single_point_data[band_name] = value

    file_point_data_list.append(single_point_data)  

# 将所有点数据转换为DataFrame  
df_all_files = pd.DataFrame(file_point_data_list)  

# 将数据导出为CSV格式（输出到新路径）
output_csv_path = os.path.join(output_folder, "random_points_with_coordinates.csv")  
df_all_files.to_csv(output_csv_path, index=False)  

print(f"处理完成! 共生成 {num_points} 个随机点")
print(f"结果已保存至: {output_csv_path}")
print(f"数据包含: {list(df_all_files.columns)}")  # 打印包含的列名
